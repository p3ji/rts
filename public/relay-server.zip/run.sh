#!/usr/bin/env bash
echo "Installing dependencies..."
npm install
echo "Starting Relay Server..."
node relay.js
